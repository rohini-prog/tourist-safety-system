const Tourist = require("../models/Tourist");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");


// REGISTER
exports.registerTourist = async (req, res) => {
try {

const { name, email, password, passport, mobile, emergencyContact } = req.body;

const existingTourist = await Tourist.findOne({ email });
if (existingTourist) {
return res.status(400).json({ message: "Email already registered" });
}

const hashedPassword = await bcrypt.hash(password, 10);
const digitalID = Math.random().toString(16).substr(2, 10);

const tourist = new Tourist({
name,
email,
password: hashedPassword,
passport,
mobile,
emergencyContact,
digitalID
});

await tourist.save();

res.status(201).json({
message: "Tourist Registered Successfully",
digitalID
});

} catch (error) {
res.status(500).json({ error: error.message });
}
};



// LOGIN
exports.loginTourist = async (req, res) => {
try {

const { email, password } = req.body;

const tourist = await Tourist.findOne({ email });

if (!tourist) {
return res.status(400).json({ message: "Tourist not found" });
}

const isMatch = await bcrypt.compare(password, tourist.password);

if (!isMatch) {
return res.status(400).json({ message: "Invalid credentials" });
}

const token = jwt.sign(
{ id: tourist._id },
"SECRET_KEY",
{ expiresIn: "1d" }
);

res.json({
message: "Login successful",
token
});

} catch (error) {
res.status(500).json({ error: error.message });
}
};



// UPDATE LOCATION + AI MOVEMENT ANALYSIS + GEO-FENCE
exports.updateLocation = async (req, res) => {

try {

const { latitude, longitude } = req.body;

const tourist = await Tourist.findById(req.user.id);

if (!tourist) {
return res.status(404).json({ message: "Tourist not found" });
}


// ---------------- AI MOVEMENT ANALYSIS ----------------

let riskStatus = "Safe";

if (tourist.location) {

const prevLat = tourist.location.latitude;
const prevLng = tourist.location.longitude;

const movementDistance =
Math.sqrt(
Math.pow(latitude - prevLat, 2) +
Math.pow(longitude - prevLng, 2)
);

if (movementDistance < 0.00005) {
riskStatus = "Warning";   // tourist not moving
}

if (movementDistance > 0.05) {
riskStatus = "Danger";    // abnormal movement
}

}


// ---------------- GEO FENCING ----------------

const dangerZones = [
{ lat:17.400, lng:78.500, radius:0.05 },
{ lat:17.420, lng:78.470, radius:0.05 },
{ lat:17.360, lng:78.520, radius:0.05 },
{ lat:17.380, lng:78.450, radius:0.05 }
];

dangerZones.forEach(zone => {

const distance =
Math.sqrt(
Math.pow(latitude - zone.lat,2) +
Math.pow(longitude - zone.lng,2)
);

if(distance < zone.radius){
riskStatus = "Danger";
}

});


// SAVE LOCATION

tourist.location = { latitude, longitude };
tourist.riskStatus = riskStatus;

await tourist.save();

res.json({
message: "Location updated successfully",
riskStatus: tourist.riskStatus
});

} catch (error) {
res.status(500).json({ error: error.message });
}

};



// SOS EMERGENCY
exports.triggerSOS = async (req, res) => {

try {

const tourist = await Tourist.findById(req.user.id);

if (!tourist) {
return res.status(404).json({ message: "Tourist not found" });
}

tourist.isEmergency = true;
tourist.riskStatus = "Danger";

await tourist.save();

res.json({
message: "Emergency alert sent",
tourist
});

} catch (error) {
res.status(500).json({ error: error.message });
}

};